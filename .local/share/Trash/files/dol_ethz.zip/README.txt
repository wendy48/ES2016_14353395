README 

This package contains the following files and directories:

./bin              contains the binaries of the tools and the used third-party libraries
./docs             contains all available documentation
./examples         contains 8 examples for illustration
./schema           contains the XML schema definitions

build_zip.xml      Ant build file
LICENSE.txt        TIK Copyright
JDOM_LICENSE.txt   JDOM Copyright
NOTICE             Apache Xerces Notice
README.txt         This file
Version.tex        Version number of the distribution
XERCES_LICENSE.txt Apache License

wh, 2008-01-23
