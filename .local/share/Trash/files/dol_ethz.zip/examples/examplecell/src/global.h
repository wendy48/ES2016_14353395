#ifndef GLOBAL_H
#define GLOBAL_H

#define LENGTH 6

#endif
