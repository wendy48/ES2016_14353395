#ifndef GLOBAL_H
#define GLOBAL_H

#define LENGTH 20

#endif
