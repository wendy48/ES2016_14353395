#ifndef GLOBAL_H
#define GLOBAL_H

#define N                 3
#define NUMBER_OF_SAMPLES 5

#endif
